﻿using UnityEngine;
using System.Collections;

public class menu : MonoBehaviour {
	public GUISkin skin;
	public static Sprite selectedHat;
	public static Sprite selectedMouth;
	public static Sprite selectedBeard;

	public static string playerName = "Player";

	public Transform hahmo;

	public static Score[] scores = new Score[10];

	public static Color selectedColor = Color.white;
	public static Color hatColor = Color.white;
	public static Color mouthColor = Color.white;
	public static Color beardColor = Color.white;

	// Use this for initialization
	void Start () 
	{
		GetComponent<fade>().StartFade(new Color(0, 0, 0, 0), 3f, false);
		//Camera.main.aspect = 3f/4f;
		if(selectedHat != null)
		{
		Transform hattu = hahmo.FindChild("Hat");
		hattu.GetComponent<SpriteRenderer>().sprite = selectedHat;
		hattu.renderer.material.color = hatColor;
		}

		if(selectedMouth != null)
		{
		Transform suu = hahmo.FindChild("Mouth");
		suu.GetComponent<SpriteRenderer>().sprite = selectedMouth;
		suu.renderer.material.color = mouthColor;
		}

		if(selectedBeard != null)
		{
		Transform parta = hahmo.FindChild("Beard");
		parta.GetComponent<SpriteRenderer>().sprite = selectedBeard;
		parta.renderer.material.color = beardColor;
		}

		hahmo.renderer.material.color = selectedColor;

		for (int i = 0; i < scores.Length; i++) 
		{
			if(scores[i] == null)
				scores[i] = new Score(0, "Player");
		}

		for (int i = 0; i < scores.Length; i++) 
		{
			scores[i].scoreNum = PlayerPrefs.GetInt("score" + i);
			scores[i].name = PlayerPrefs.GetString("scorename" + i);
		}
		mouse.coinsCollected = PlayerPrefs.GetInt ("money");
		


		
	}

	void OnGUI()
	{
		GUI.skin = skin;

		if (GUI.Button (new Rect (5, Screen.height - 140, 300, 120), "RESET")) 
		{
			for (int i = 0; i < scores.Length; i++) 
			{
				scores[i] = new Score(0, "Player");
				
				PlayerPrefs.SetInt("score" + i, menu.scores[i].scoreNum);
				PlayerPrefs.SetString("scorename" + i, menu.scores[i].name);
			}
			
			PlayerPrefs.Save();
		}

		if(GUI.Button(new Rect(Screen.width/2 - 50,Screen.height/2 + 260,100, 40), "CUSTOMIZE", skin.customStyles[0]))
			Application.LoadLevel("customize");

		if (GUI.Button (new Rect (0, 0, Screen.width, Screen.height), "")) 
		{
			GetComponent<fade>().StartFade(Color.black, 1f, true);
		}

		for (int i = 0; i < scores.Length; i++) 
		{
			GUI.Label(new Rect(10, 100 + i * 45, 300, 60), "<size=30>" + scores[i].name + ": " + scores[i].scoreNum + "</size>");
		}


	}

	void Update()
	{
		if(fade.doneFading)
			Application.LoadLevel ("game");
	}
}