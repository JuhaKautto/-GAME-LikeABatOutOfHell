﻿using UnityEngine;
using System.Collections;

public class adsads : MonoBehaviour {
	
	// Use this for initialization
	void Awake () {
		//Camera.main.aspect = 3f/4f;
	}
	
	// Update is called once per frame
	void Update () {
	}
}
