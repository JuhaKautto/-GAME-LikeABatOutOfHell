﻿using UnityEngine;
using System.Collections;

public class minePlacer : MonoBehaviour {
	public Transform mine;
	int mineAmount;
	float radius;
	int noMine = Random.Range(2, 7);
	// Use this for initialization
	void Start () {
		mineAmount = 8;
		radius = Random.Range (5f, 25f);

		for (int i = 0; i < mineAmount; i++) 
		{
			if(i != noMine && i != noMine + 1)
			Instantiate(mine, new Vector2(transform.position.x, transform.position.y - i * 1.5f), mine.rotation);
		}
	}

	int randomKerroin()
	{
		if (Random.Range (1, 3) == 1)
			return -1;

		else
			return 1;
	}

	// Update is called once per frame
	void Update () {
	
	}
}
