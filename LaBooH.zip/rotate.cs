﻿using UnityEngine;
using System.Collections;

public class rotate : MonoBehaviour {
	float randomScale = Random.Range(1f, 2f);
	float randomSpeed = Random.Range(1f, 4f);
	// Use this for initialization
	void Start () {
		transform.localScale = new Vector3 (randomScale, randomScale, 0f);

		if (Random.Range (1, 3) == 2)
			randomSpeed *= -1;
	}
	
	// Update is called once per frame
	void Update () {
		transform.Rotate(new Vector3(0f, 0f, randomSpeed * Time.deltaTime * 50));
	}
}
