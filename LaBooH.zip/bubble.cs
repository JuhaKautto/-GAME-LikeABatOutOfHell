﻿using UnityEngine;
using System.Collections;

public class bubble : MonoBehaviour {
	float scale = 1f;
	float startX;
	// Use this for initialization
	void Start () {
		scale = Random.Range (0.5f, 1f);
		transform.renderer.material.color = Color.red;
		transform.localScale = new Vector3 (scale, scale, scale);
		startX = transform.position.x;
	}
	
	// Update is called once per frame
	void Update () {
		if (transform.position.x > startX + 100f) 
		{
			Destroy(gameObject);
		}
		//transform.rigidbody2D.velocity = new Vector2 (transform.rigidbody2D.velocity.x, transform.rigidbody2D.velocity.y - 0.1f);
	}
}
