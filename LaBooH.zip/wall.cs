﻿using UnityEngine;
using System.Collections;

public class wall : MonoBehaviour {
	GameObject ball;
	// Use this for initialization
	void Start () {
		ball = GameObject.Find ("Hahmo(Clone)");

		if(transform.name == "Wall1")
			transform.position = new Vector3 (transform.position.x, transform.position.y + 0.5f, transform.position.z);

		if(transform.name == "Wall2")
			transform.position = new Vector3 (transform.position.x, transform.position.y - 0.5f, transform.position.z);
	}
	
	// Update is called once per frame
	void Update () {
		transform.position = new Vector3 (ball.transform.position.x, transform.position.y, 0);
	}
}
