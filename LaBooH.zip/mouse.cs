﻿using UnityEngine;
using System.Collections;

public class mouse : MonoBehaviour 
{
	Vector2 mouseLocation;
	public Transform pallo;
	public Transform platform;
	public Transform enemy;
	public Transform wall;
	public Transform bg;
	public Transform coin;
	public Transform spikeball;
	public Transform minePlacer;
	public Transform cannon;
	public Transform boss;

	bool mammon = false;

	public static int coinsCollected = 0;
	public Texture2D coinTex;
	public GUIStyle style;

	public AudioClip music;
	public static int score;

	public int obstacleEndX = 20;
	public int requiredCharX = 0;
	Transform hahmo;

	void createObstacle(float x, float y, Transform obstacle)
	{
		Transform o = Instantiate(obstacle, new Vector2(x, y), obstacle.rotation) as Transform;
		Instantiate(coin, new Vector2(o.position.x + 1, Random.Range(-3.5f, 3.5f)), coin.rotation);
	}

	// Use this for initialization
	void Start () {
		audio.clip = music;
		audio.Play();
		audio.volume = 0.2f;
		audio.loop = true;

//		for (int i = 5; i < obstacleEndX; i+=Random.Range(3, 7)) 
//		{
//			int random = Random.Range(1, 101);
//	
//			if(random > 0 && random <= 50)
//			{
//			Transform obstacle = Instantiate(platform, new Vector2(i, Random.Range(-3.5f, 3.5f)), platform.rotation) as Transform;
//			obstacle.GetComponent<obstacle1>().holeWidth = Random.Range(4f, 5.5f);
//			}
//			
//
//			else if (random > 50 && random < 62)
//			{
//			Transform lintu = Instantiate(enemy, new Vector2(i, Random.Range(-3.5f, 3.5f)), enemy.rotation) as Transform;
//			}
//
//			else if(random >= 62 && random < 75)
//			{
//				Transform piikkipallo = Instantiate(spikeball, new Vector2(i, Random.Range(-3.5f, 3.5f)), spikeball.rotation) as Transform;
//			}
//
//			else if (random >= 75 && random < 87)
//			{
//				Transform Placer = Instantiate(minePlacer, new Vector2(i, 6f), minePlacer.rotation) as Transform;
//			}
//
//			else
//			{	
//				Transform kanuuna = Instantiate(cannon, new Vector2(i, Random.Range(-3.5f, 3.5f)), cannon.rotation) as Transform;
//			}
//
//
//			Instantiate(coin, new Vector2(i+1, Random.Range(-3.5f, 3.5f)), coin.rotation);
//		}

		for (int i = 0; i < 55; i++)
		{
			Instantiate(bg, new Vector3(-15 + i * 10.24f, 0, 5), bg.rotation);
		}

		hahmo = Instantiate(pallo, Vector3.zero, pallo.rotation) as Transform;

		Transform hattu = hahmo.FindChild("Hat");
		hattu.GetComponent<SpriteRenderer>().sprite = menu.selectedHat;
		hattu.renderer.material.color = menu.hatColor;

		Transform suu = hahmo.FindChild("Mouth");
		suu.GetComponent<SpriteRenderer>().sprite = menu.selectedMouth;
		suu.renderer.material.color = menu.mouthColor;

		Transform parta = hahmo.FindChild("Beard");
		parta.GetComponent<SpriteRenderer>().sprite = menu.selectedBeard;
		parta.renderer.material.color = menu.beardColor;

		hahmo.renderer.material.color = menu.selectedColor;


		Transform seina = Instantiate (wall, Camera.main.ScreenToWorldPoint(new Vector3(0, Screen.height, 0)), wall.rotation) as Transform;
		seina.localScale = new Vector3 (seina.localScale.x, 155, seina.localScale.z);
		seina.position = new Vector3 (seina.position.x + seina.localScale.x / 2, seina.position.y, 0);
		seina.name = "Wall1";

		Transform seina2 = Instantiate (wall, Camera.main.ScreenToWorldPoint(new Vector3(0, 0, 0)), wall.rotation) as Transform;
		seina2.localScale = new Vector3 (seina.localScale.x, 155, seina.localScale.z);
		seina2.position = new Vector3 (seina2.position.x - seina2.localScale.x / 2, seina2.position.y, 0);
		seina2.name = "Wall2";

	}

	void OnGUI()
	{
		GUI.DrawTexture (new Rect (Screen.width - 150, 10, 50, 50), coinTex);
		GUI.Label (new Rect (Screen.width - 80, 10, 50, 50), "" + coinsCollected, style);

		GUI.Label (new Rect (10, 10, 100, 50), Mathf.Floor(hahmo.position.x) + "m", style);
	}

	// Update is called once per frame
	void Update () 
	{
		if (Random.Range (1, 150) == 1 && !mammon) 
		{
			Instantiate(boss, new Vector2(hahmo.position.x - 12f, hahmo.position.y), boss.rotation);
			mammon = true;
		}

		score = (int)Mathf.Floor (hahmo.position.x);
		transform.position = new Vector3 (hahmo.position.x, 0, -10);
//		if (Input.GetMouseButton (0)) {
//			mouseLocation = Camera.main.ScreenToWorldPoint (Input.mousePosition);
//			Vector2 suunta = new Vector2 (mouseLocation.x - hahmo.position.x, mouseLocation.y - hahmo.position.y);
//
//			hahmo.rigidbody2D.AddForce (new Vector2(suunta.x * 5, suunta.y * 15));
//			hahmo.rigidbody2D.drag = 0;
//		}

		if (hahmo.position.x > requiredCharX) 
		{
			int nextX = Random.Range(3, 7);

			requiredCharX += nextX;

			int dx = Random.Range(1, 101);

			if(dx > 0 && dx <= 50)
				createObstacle(obstacleEndX, Random.Range(-3.5f, 3.5f), platform);
			
			else if(dx > 50 && dx < 62)
				createObstacle(obstacleEndX, 0, enemy);

			else if(dx >= 62 && dx < 75)
				createObstacle(obstacleEndX, Random.Range(-3.5f, 3.5f), spikeball);

			else if(dx >= 75 && dx < 87)
				createObstacle(obstacleEndX, 6f, minePlacer);

			else
				createObstacle(obstacleEndX, Random.Range(-3.5f, 3.5f), cannon);

			obstacleEndX += nextX;
		}

		foreach(GameObject g in GameObject.FindObjectsOfType(typeof(GameObject)))
		{
			if(g.transform.position.x < hahmo.position.x - 20 && (g.gameObject.tag == "X" || g.gameObject.tag == "Enemy"))
				Destroy(g);
		}
	}
}
