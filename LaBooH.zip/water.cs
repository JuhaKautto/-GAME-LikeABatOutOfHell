﻿using UnityEngine;
using System.Collections;

public class water : MonoBehaviour {
	public float riseSpeed;
	public Transform lavaBubble;
	// Use this for initialization
	void Start () {
		transform.renderer.material.color = Color.red;
	}

	// Update is called once per frame
	void Update () {
		transform.position = new Vector3 (transform.position.x + riseSpeed, transform.position.y , -5);

		if (Random.Range (1, 160) == 1) 
		{
			Transform bubble = Instantiate(lavaBubble, new Vector2(transform.position.x, Random.Range(-3.5f, 3.5f)), lavaBubble.rotation) as Transform;
			bubble.rigidbody2D.velocity = new Vector2(Random.Range(6, 12), 0);
		}
	}
}
