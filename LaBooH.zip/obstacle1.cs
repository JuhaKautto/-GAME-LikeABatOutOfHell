﻿using UnityEngine;
using System.Collections;

public class obstacle1 : MonoBehaviour {
	public float holeWidth;
	// Use this for initialization
	void Start () {
		holeWidth = Random.Range(4f, 5.5f);
		transform.FindChild ("Cube1").position = new Vector2 (transform.position.x , transform.position.y- holeWidth);
		transform.FindChild ("Cube2").position = new Vector2 (transform.position.x , transform.position.y+ holeWidth);
	}
	
	// Update is called once per frame
	void Update () {

//		foreach(GameObject x in GameObject.FindGameObjectsWithTag("Enemy"))
//		{
//			if(Vector2.Distance(gameObject.transform.position, x.transform.position) < 2f)
//				Destroy(x);
//		}

	}
}
