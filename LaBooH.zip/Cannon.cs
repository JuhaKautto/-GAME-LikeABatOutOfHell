﻿using UnityEngine;
using System.Collections;

public class Cannon : MonoBehaviour {
	public Transform ammo;
	float angle = 0;
	float timer = 10f;

	// Use this for initialization
	void Start () {
	
	}

	void Shoot()
	{
		for (int i = 0; i < 8; i++) 
		{
			Transform ammus = Instantiate(ammo, new Vector2(transform.position.x + Mathf.Sin(Mathf.Deg2Rad * angle + transform.rotation.z) , transform.position.y + Mathf.Cos(Mathf.Deg2Rad * angle + transform.rotation.z)) , ammo.rotation) as Transform; 
			ammus.rigidbody2D.velocity = new Vector2(Mathf.Sin(Mathf.Deg2Rad * angle + transform.rotation.z) * 5f, Mathf.Cos(Mathf.Deg2Rad * angle + transform.rotation.z) * 5f);
			angle += 45f;
		}
	}
	// Update is called once per frame
	void Update () {
		if (timer >= 0f)
			timer-= Time.deltaTime * 10f;

		if (timer <= 0f) {
			timer = Random.Range(30f, 60f);
			Shoot();
				}



		transform.Rotate(new Vector3(0f,0f, 2f));
	}
}
