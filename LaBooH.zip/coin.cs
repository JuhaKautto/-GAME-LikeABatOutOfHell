﻿using UnityEngine;
using System.Collections;

public class coin : MonoBehaviour {
	public int value = 1;
	// Use this for initialization
	void Start () {
		int random = Random.Range (1, 101);

		if (random <= 60) 
		{
			value = 1;
			transform.renderer.material.color = new Color(0.6f,0.2f,0f,1);
		}

		else if (random > 60 && random < 90) 
		{
			value = 5;
			transform.renderer.material.color = Color.white;
		} 

		else 
		{
			value = 10;
			transform.renderer.material.color = Color.yellow;
		}
	}



	// Update is called once per frame
	void Update () {
	
	}
}
