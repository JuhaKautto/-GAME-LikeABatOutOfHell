﻿using UnityEngine;
using System.Collections;

public class boss : MonoBehaviour {
	Vector3[] points = new Vector3[2];
	float speed = 1.0f; //how fast it shakes
	float amount = 0.1f; //how much it shakes


	
	// Use this for initialization
	void Start () {
		points [0] = new Vector3 (transform.position.x + 10f, 3f, 0f);
		points [1] = new Vector3 (transform.position.x + 30f, -2f, 0f);
	}
	
	// Update is called once per frame
	void Update () {

//		transform.position = Vector3.MoveTowards(transform.position, points[0], 0.09f);
//		transform.position = new Vector3(transform.position.x, transform.position.y + Mathf.Sin(Time.time * speed) * amount, transform.position.z);
//
//		if (Vector3.Distance (transform.position, points [0]) < 0.2f) 
//		{
//			points[0] = points[1];
//			points[1] = new Vector3(points[0].x + 10f, Random.Range(-3f, 3f));
//		}

		transform.position = new Vector3 (transform.position.x + 0.22f, transform.position.y, -1f);

		if(Vector3.Distance(GameObject.Find("Hahmo(Clone)").transform.position, transform.position) < 2f)
			mouse.coinsCollected--;
	}
}
