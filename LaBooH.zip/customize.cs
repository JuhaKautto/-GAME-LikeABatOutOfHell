﻿using UnityEngine;
using System.Collections;

public class customize : MonoBehaviour {
	public Texture2D[] hats = new Texture2D[2];
	public Texture2D[] mouths = new Texture2D[3];
	public Texture2D[] beards = new Texture2D[1];

	int selected = 0;
	public static GameObject character;
	Color charColor = Color.white;
	Color objectColor = Color.white;

	Transform selectedObject = null;
	
	// Use this for initialization
	void Start () 
	{
		character = GameObject.Find ("Hahmo");
	}

	public static Color ColorPicker(Rect rect, Color color)
	{
		//Create a blank texture.
		Texture2D tex = new Texture2D(40,40);

		GUILayout.BeginArea(rect,"","Box");
		
		#region Slider block
		GUILayout.BeginHorizontal();
		GUILayout.BeginVertical("Box");
		//Sliders for rgb variables betwen 0.0 and 1.0
		GUILayout.BeginHorizontal();
		GUILayout.Label("R",GUILayout.Width(10));
		color.r = GUILayout.HorizontalSlider(color.r,0f,1f);
		GUILayout.EndHorizontal();
		
		GUILayout.BeginHorizontal();
		GUILayout.Label("G",GUILayout.Width(10));
		color.g = GUILayout.HorizontalSlider(color.g,0f,1f);
		GUILayout.EndHorizontal();
		
		GUILayout.BeginHorizontal();
		GUILayout.Label("B",GUILayout.Width(10));
		color.b = GUILayout.HorizontalSlider(color.b,0f,1f);
		GUILayout.EndHorizontal();
		GUILayout.EndVertical();
		#endregion
		
		//Color Preview
		GUILayout.BeginVertical("Box",new GUILayoutOption[]{GUILayout.Width(44),GUILayout.Height(44)});
		//Apply color to following label
		GUI.color = color;
		GUILayout.Label(tex);
		//Revert color to white to avoid messing up any following controls.
		GUI.color = Color.white;
		
		GUILayout.EndVertical();
		GUILayout.EndHorizontal();
		
		//Give color as RGB values.
		GUILayout.Label("Current Colour = " + (int)(color.r * 255) + "|" + (int)(color.g * 255) + "|" + (int)(color.b * 255));
		
		GUILayout.EndArea();
		//Finally return the modified value.
		return color;
	}


	void OnGUI()
	{
		menu.playerName = GUI.TextField(new Rect(305, 5, 100, 50), menu.playerName);

		if (GUI.Button (new Rect (0, Screen.height - 30, 100, 30), "BACK")) {
			Application.LoadLevel("menu");
		}

		if (GUI.Button (new Rect (5, 10, 100, 40), "HATS")) {
			selected = 1;
			selectedObject = null;
		}

		if (selected == 1) 
		{
			int y = 60;
			int x = 5;

			for (int i = 0; i < hats.Length; i++) 
			{

				if (GUI.Button (new Rect (x, y, 50, 50), hats [i])) 
				{
							Transform hattu = character.transform.FindChild ("Hat");
							hattu.GetComponent<SpriteRenderer> ().sprite = Sprite.Create (hats [i], new Rect (0, 0, hats [i].width, hats [i].height), new Vector2 (0.5f, 0.5f));
							menu.selectedHat = hattu.GetComponent<SpriteRenderer> ().sprite;
							selectedObject = hattu;
				}

				if(i % 5 == 0 && i != 0){
					y += 60;
					x = 5;
					x -= 60;
				}

				x += 60;
			}
		}

		if (GUI.Button (new Rect (115, 10, 100, 40), "MOUTHS")) {
			selected = 2;
			selectedObject = null;
		}

		if(selected == 2)
		for (int i = 0; i < mouths.Length; i++)
		{
			if (GUI.Button (new Rect (5 + i * 70, 60, 50, 50), mouths[i])) 
			{
				Transform suu = character.transform.FindChild("Mouth");
				suu.GetComponent<SpriteRenderer>().sprite = Sprite.Create(mouths[i], new Rect(0, 0, mouths[i].width, mouths[i].height), new Vector2(0.5f, 0.5f));
				menu.selectedMouth = suu.GetComponent<SpriteRenderer>().sprite;
				selectedObject = suu;
			}
		}

		if (GUI.Button (new Rect (225, 10, 100, 40), "BEARDS")) {
			selected = 3;
			selectedObject = null;
		}

		if(selected == 3)
			for (int i = 0; i < beards.Length; i++)
			{
				if (GUI.Button (new Rect (5 + i * 70, 60, 50, 50), beards[i])) 
				{
				Transform parta = character.transform.FindChild("Beard");
				parta.GetComponent<SpriteRenderer>().sprite = Sprite.Create(beards[i], new Rect(0, 0, beards[i].width, beards[i].height), new Vector2(0.5f, 0.5f));
				menu.selectedBeard = parta.GetComponent<SpriteRenderer>().sprite;
				selectedObject = parta;
				}
			}

		charColor = ColorPicker(new Rect(50,150,120,120),charColor);

		if(selectedObject != null)
		objectColor = ColorPicker(new Rect(50,350,120,120),objectColor);

		if (selectedObject != null) 
		{
			selectedObject.renderer.material.color = objectColor;

			switch(selected)
			{
				case 1:
				{
					menu.hatColor = objectColor;
					break;
				}

				case 2:
				{
					menu.mouthColor = objectColor;
					break;
				}

				case 3:
				{
					menu.beardColor = objectColor;
					break;
				}


			}
		}

		menu.selectedColor = new Color(charColor.r, charColor.g, charColor.b, 1);
		character.renderer.material.color = menu.selectedColor;


		}
	// Update is called once per frame
	void Update () {
	}
}
