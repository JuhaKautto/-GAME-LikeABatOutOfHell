﻿using UnityEngine;
using System.Collections;

public class enemy : MonoBehaviour {
	float speed = 0.1f;
	float timer = 0f;
	// Use this for initialization
	void Start () {
		speed = Random.Range (10f, 17f);
	}

	void OnCollisionEnter2D(Collision2D c)
	{
//		speed *= -1;

		if (c.gameObject.tag == "Water")
			Destroy (gameObject);
	}

	// Update is called once per frame
	void Update () {
		if ((transform.position.y < -4f || transform.position.y > 4f) && timer <= 0f)
		{
			speed *= -1;
			timer = 1f;
		}

		if (timer > 0f) 
		{
			timer -= Time.deltaTime * 5f;
		}

		transform.rigidbody2D.velocity = new Vector2 (transform.rigidbody2D.velocity.x, speed * Time.deltaTime * 50);
		transform.Rotate(new Vector3(0f, 0f, 500f));


	}
}
