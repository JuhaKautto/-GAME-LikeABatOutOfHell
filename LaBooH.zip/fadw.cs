﻿using UnityEngine;
using System.Collections;

public class fadw : MonoBehaviour {
	bool kasvaa = false;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if(kasvaa == false)
			transform.renderer.material.color = new Color (1, 1, 1, transform.renderer.material.color.a - 0.02f);

		else
			transform.renderer.material.color = new Color (1, 1, 1, transform.renderer.material.color.a + 0.04f);

		if (transform.renderer.material.color.a <= 0f)
			kasvaa = true;

		else if (transform.renderer.material.color.a >= 1f)
			kasvaa = false;
	}
}
