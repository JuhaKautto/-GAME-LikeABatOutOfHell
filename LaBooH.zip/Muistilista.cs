﻿/*
 * - Bossi
 * - Customize-menu
 * - Mikro-ostot
 * - Paikallaan olevat piikkipallot
 * - Muut esteet (laavasade)
 * - Highscoret
 * - Hyvät ääniefektit
 * - Background-kuva
 */