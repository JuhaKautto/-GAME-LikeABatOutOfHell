﻿using UnityEngine;
using System.Collections;

public class ball : MonoBehaviour {
	public static float immunity = 0f;
	public AudioClip coinCollect;
	public AudioClip deathScream;
	bool dead = false;
	float gravity = 6f;

	// Use this for initialization
	void Start () 
	{
		GetComponent<fade>().StartFade(new Color(0, 0, 0, 0), 3f, false);
		//rigidbody2D.AddForce (new Vector2 (200, 450));
	}

	void Death()
	{
		if (!dead) 
		{
			GetComponent<fade> ().StartFade (Color.black, 1f, true);
			audio.PlayOneShot (deathScream, 0.2f);
			transform.renderer.material.color = new Color (0f, 0f, 0f, 0f);
			dead = true;

			int index = 0;
			while(true)
			{
				if(menu.scores[index].scoreNum < mouse.score)
				{
					for(int i = 9; i > index; i--)
					{
						menu.scores[i] = menu.scores[i - 1];
					}

					menu.scores[index] = new Score(mouse.score, menu.playerName);
					break;
				}

				index++;

				if(index == 10)
					break;
			}

			for(int i = 0; i < menu.scores.Length; i++)
			{
				PlayerPrefs.SetInt("score" + i, menu.scores[i].scoreNum);
				PlayerPrefs.SetString("scorename" + i, menu.scores[i].name);
			}

			PlayerPrefs.SetInt("money", mouse.coinsCollected);
			PlayerPrefs.Save();
		}
	}

	void OnCollisionEnter2D(Collision2D c)
	{
		if (c.transform.tag == "Water" || c.transform.tag == "Enemy")
		{
			Death();
		}
	}

	void OnTriggerEnter2D(Collider2D c)
	{
		if (c.gameObject.tag == "Coin") 
		{
			audio.PlayOneShot(coinCollect);
			mouse.coinsCollected+= c.GetComponent<coin>().value;
			Destroy (c.gameObject);
		}

		else if(c.gameObject.tag == "Bubble" || c.transform.tag == "Enemy")
			Death();
	}

//	void OnCollisionStay2D(Collision2D c)
//	{
//		if(immunity <= 0f)
//			rigidbody2D.velocity = Vector2.zero;
//	}

	// Update is called once per frame
	void Update () {
		if (Input.GetMouseButtonDown (0)) {
			gravity = -gravity;
		}

		if(Application.loadedLevelName == "game")
		rigidbody2D.velocity = new Vector2(6f, gravity);

		if (immunity >= 0f)
			immunity -= 1f;

		if (fade.doneFading)
			Application.LoadLevel ("menu");
	}
}
