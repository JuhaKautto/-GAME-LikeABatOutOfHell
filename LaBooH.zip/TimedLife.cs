﻿using UnityEngine;
using System.Collections;

public class TimedLife : MonoBehaviour {
	public float lifetime = 10f;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	if(lifetime > 0f)
			lifetime -= Time.deltaTime * 10f;

	else
			Destroy(gameObject);
	}
}
